#!/usr/bin/env bash
# Write the routine webhook key to ~/.config/sales-bot-kit/routine_key
# (directory mode 0700, file mode 0600) so the relay and watchdog can read
# it after a restart, when the bot secret is not in their environment.
#
# Usage:  set-routine-key.sh
# Reads the key only from the WA_ROUTINE_WEBHOOK_KEY environment variable
# (the Grok Bot secret). Never prints, echoes, or logs the key.
set -euo pipefail

KEY_ENV="WA_ROUTINE_WEBHOOK_KEY"
if [[ -n "${WA_ROUTINE_KEY_FILE:-}" ]]; then
  DEST="${WA_ROUTINE_KEY_FILE}"
elif [[ -n "${XDG_CONFIG_HOME:-}" ]]; then
  DEST="${XDG_CONFIG_HOME}/sales-bot-kit/routine_key"
else
  DEST="${HOME}/.config/sales-bot-kit/routine_key"
fi

key="${WA_ROUTINE_WEBHOOK_KEY:-}"
# trim surrounding whitespace without printing the value
key="${key#"${key%%[![:space:]]*}"}"
key="${key%"${key##*[![:space:]]}"}"

if [[ -z "$key" ]]; then
  echo "error: ${KEY_ENV} is not set. Save the routine key as a bot secret named ${KEY_ENV}, then run this script again." >&2
  exit 1
fi

umask 077
dest_dir="$(dirname "$DEST")"
mkdir -p "$dest_dir"
chmod 700 "$dest_dir"
tmp="$(mktemp "$dest_dir/.routine_key.XXXXXX")"
# Write exactly the trimmed key plus a trailing newline. Do not echo it.
printf '%s\n' "$key" > "$tmp"
chmod 600 "$tmp"
mv -f "$tmp" "$DEST"
chmod 600 "$DEST"
echo "wrote the routine key file (mode 0600). The key was not printed."
