#!/usr/bin/env bash
# Stop the WhatsApp bridge and the local relay. Does not touch the session.
# Usage: stop-bridge.sh [--bridge-only]
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/lib.sh"

stop_pid() {
  local label="$1" pid="$2"
  is_running "$pid" || return 1
  kill "$pid" 2>/dev/null || true
  for _ in $(seq 1 20); do
    if ! is_running "$pid"; then
      echo "stopped $label (pid $pid)"
      return 0
    fi
    sleep 0.25
  done
  echo "$label pid $pid did not exit, sending SIGKILL" >&2
  kill -9 "$pid" 2>/dev/null || true
  echo "stopped $label (pid $pid, killed)"
}

stop_all() {
  local label="$1" pidfile="$2" pattern="$3" any=0 pid
  if [[ -f "$pidfile" ]]; then
    pid="$(cat "$pidfile" 2>/dev/null || true)"
    stop_pid "$label" "$pid" && any=1
    rm -f "$pidfile"
  fi
  while read -r pid; do
    [[ -z "$pid" ]] && continue
    stop_pid "$label" "$pid" && any=1
  done < <(pgrep -f "$pattern" || true)
  [[ "$any" -eq 1 ]] || echo "$label is not running"
}

stop_all "bridge" "$BRIDGE_PIDFILE" "^${BIN}( |$)"
if [[ "${1:-}" != "--bridge-only" ]]; then
  stop_all "relay" "$RELAY_PIDFILE" "python3 ${RELAY_PY}"
fi
