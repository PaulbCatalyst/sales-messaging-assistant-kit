#!/usr/bin/env python3
"""Local WhatsApp webhook relay (sales bot kit).

Listens for POSTs from the whatsapp-mcp bridge (verygoodplugins/whatsapp-mcp)
and forwards a filtered, debounced JSON event to a Grok Bot routine webhook.

Every setting comes from config.json. Lookup order: $RELAY_CONFIG, then
config.json next to this script, then config.json one directory up.
The routine webhook key comes from the environment variable
WA_ROUTINE_WEBHOOK_KEY, or if that is unset, from the file written by
set-routine-key.sh (~/.config/sales-bot-kit/routine_key). It is never
printed or logged, and message text is never logged.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

KEY_ENV = "WA_ROUTINE_WEBHOOK_KEY"
HERE = Path(__file__).resolve().parent


# ---------------------------------------------------------------- config

def _config_path() -> Path:
    env = (os.environ.get("RELAY_CONFIG") or "").strip()
    if env:
        return Path(env).expanduser()
    for cand in (HERE / "config.json", HERE.parent / "config.json"):
        if cand.exists():
            return cand
    raise SystemExit(
        "relay: no config.json found. Set RELAY_CONFIG or put config.json next to relay.py or one level up."
    )


def _load_config() -> dict:
    path = _config_path()
    with path.open(encoding="utf-8") as f:
        cfg = json.load(f)
    if not isinstance(cfg, dict):
        raise SystemExit(f"relay: {path} must contain a JSON object")
    return cfg


CFG = _load_config()
_R = CFG.get("relay") or {}
_F = CFG.get("filters") or {}
_B = CFG.get("bridge") or {}

INSTALL_DIR = Path(os.path.expanduser(str(CFG.get("install_dir") or "~/whatsapp-mcp")))
KIT_DIR = INSTALL_DIR / "kit"
RUN_DIR = KIT_DIR / "run"
LOG_PATH = RUN_DIR / "relay.log"
PID_PATH = RUN_DIR / "relay.pid"
BRIDGE_DIR = INSTALL_DIR / "whatsapp-bridge"
MESSAGES_DB = BRIDGE_DIR / "store" / "messages.db"
WHATSAPP_DB = BRIDGE_DIR / "store" / "whatsapp.db"
BRIDGE_TOKEN_PATH = BRIDGE_DIR / "store" / ".bridge-token"

LISTEN_HOST = str(_R.get("listen_host") or "127.0.0.1")
LISTEN_PORT = int(_R.get("listen_port") or 8769)
WEBHOOK_PATH = str(_R.get("webhook_path") or "/whatsapp/webhook")
HEALTH_PATH = str(_R.get("health_path") or "/health")
DEBOUNCE_SEC = float(_R.get("debounce_sec", 90))
RATE_LIMIT_SEC = float(_R.get("rate_limit_sec", 300))
MAX_AGE_SEC = float(_R.get("max_age_sec", 600))
SQLITE_TIMEOUT = 5.0

ROUTINE_URL = str(CFG.get("routine_url") or "").strip()
TIME_ZONE = str(CFG.get("time_zone") or "UTC")
_QH = CFG.get("quiet_hours") or {}
QUIET_START = str(_QH.get("start") or "")
QUIET_END = str(_QH.get("end") or "")

ACCEPT_DMS = bool(_F.get("accept_dms", True))
GROUP_NAME_NEEDLES = tuple(str(n).lower() for n in (_F.get("group_name_needles") or []) if str(n).strip())
GROUP_DENY_NEEDLES = tuple(str(n).lower() for n in (_F.get("group_deny_needles") or []) if str(n).strip())
# "none": drop everything the user sends. "deals_only": forward own messages
# only when they match own_message_regex (deal logging). "all": forward all.
FORWARD_OWN = str(_F.get("forward_own_messages") or "none").lower()
_OWN_RE_SRC = str(_F.get("own_message_regex") or "")
OWN_RE = re.compile(_OWN_RE_SRC, re.IGNORECASE) if _OWN_RE_SRC else None

SKIP_MEDIA_TYPES = {"reaction", "protocol", "system", "revoked"}


# ---------------------------------------------------------------- time

def _tz():
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(TIME_ZONE)
    except Exception:
        return timezone(timedelta(0))


def local_now() -> datetime:
    return datetime.now(_tz())


def _hm(s: str) -> int | None:
    try:
        h, m = s.split(":", 1)
        return int(h) * 60 + int(m)
    except Exception:
        return None


def in_quiet_hours(now: datetime | None = None) -> bool:
    start, end = _hm(QUIET_START), _hm(QUIET_END)
    if start is None or end is None or start == end:
        return False
    now = now or local_now()
    cur = now.hour * 60 + now.minute
    if start < end:
        return start <= cur < end
    return cur >= start or cur < end


def log(msg: str) -> None:
    line = f"{local_now().strftime('%Y-%m-%d %H:%M:%S %Z')} {msg}"
    try:
        RUN_DIR.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        print(line, flush=True, file=sys.stderr)


# ---------------------------------------------------------------- secrets

def load_bridge_token() -> str:
    try:
        return BRIDGE_TOKEN_PATH.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def key_file_path() -> Path:
    override = (os.environ.get("WA_ROUTINE_KEY_FILE") or "").strip()
    if override:
        return Path(override).expanduser()
    xdg = (os.environ.get("XDG_CONFIG_HOME") or "").strip()
    base = Path(xdg).expanduser() if xdg else Path.home() / ".config"
    return base / "sales-bot-kit" / "routine_key"


def get_routine_key() -> str:
    """Return the routine webhook key. Never prints or logs it.

    Looks in WA_ROUTINE_WEBHOOK_KEY first, then the file written by
    set-routine-key.sh (~/.config/sales-bot-kit/routine_key).
    """
    val = (os.environ.get(KEY_ENV) or "").strip()
    if val:
        return val
    try:
        return key_file_path().read_text(encoding="utf-8").strip()
    except Exception:
        return ""

# ---------------------------------------------------------------- sqlite lookups

def _connect_ro(path: Path) -> sqlite3.Connection | None:
    if not path.exists():
        return None
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=SQLITE_TIMEOUT)
        con.row_factory = sqlite3.Row
        return con
    except Exception as e:
        log(f"db_open_failed path={path.name} err={type(e).__name__}")
        return None


def lookup_group_name(chat_jid: str) -> str | None:
    con = _connect_ro(MESSAGES_DB)
    if not con:
        return None
    try:
        row = con.execute("SELECT name FROM chats WHERE jid = ?", (chat_jid,)).fetchone()
        return (row["name"] if row else None) or None
    except Exception as e:
        log(f"group_name_lookup_failed chat={chat_jid} err={type(e).__name__}")
        return None
    finally:
        con.close()


def _parse_ts(raw: Any) -> datetime | None:
    if raw is None:
        return None
    tz = _tz()
    if isinstance(raw, datetime):
        return raw if raw.tzinfo else raw.replace(tzinfo=tz)
    if isinstance(raw, (int, float)):
        if raw > 10_000_000_000:
            raw = raw / 1000.0
        return datetime.fromtimestamp(raw, tz=tz)
    s = str(raw).strip()
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s.replace(" ", "T", 1))
        return dt if dt.tzinfo else dt.replace(tzinfo=tz)
    except Exception:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s[:19], fmt).replace(tzinfo=tz)
        except Exception:
            continue
    return None


def lookup_timestamp(message_id: str, chat_jid: str) -> datetime | None:
    if not message_id or not chat_jid:
        return None
    con = _connect_ro(MESSAGES_DB)
    if not con:
        return None
    try:
        row = con.execute(
            "SELECT timestamp FROM messages WHERE id = ? AND chat_jid = ?",
            (message_id, chat_jid),
        ).fetchone()
        if not row or not row["timestamp"]:
            return None
        return _parse_ts(row["timestamp"])
    except Exception as e:
        log(f"timestamp_lookup_failed chat={chat_jid} err={type(e).__name__}")
        return None
    finally:
        con.close()


def lookup_sender_name(sender: str) -> str:
    sender = (sender or "").strip()
    if not sender:
        return "unknown"
    candidates = [sender]
    if "@" not in sender:
        candidates += [f"{sender}@s.whatsapp.net", f"{sender}@lid"]
    con = _connect_ro(WHATSAPP_DB)
    if not con:
        return sender
    try:
        qmarks = ",".join("?" * len(candidates))
        rows = con.execute(
            "SELECT full_name, push_name, first_name, business_name, their_jid "
            f"FROM whatsmeow_contacts WHERE their_jid IN ({qmarks})",
            candidates,
        ).fetchall()
        if not rows and "@" not in sender:
            rows = con.execute(
                "SELECT full_name, push_name, first_name, business_name, their_jid "
                "FROM whatsmeow_contacts WHERE their_jid LIKE ?",
                (sender + "@%",),
            ).fetchall()
        for row in rows:
            for col in ("full_name", "push_name", "first_name", "business_name"):
                val = (row[col] or "").strip()
                if val:
                    return val
    except Exception as e:
        log(f"sender_name_lookup_failed err={type(e).__name__}")
    finally:
        con.close()
    return sender


def sender_jid(sender: str) -> str:
    sender = (sender or "").strip()
    if not sender:
        return ""
    return sender if "@" in sender else f"{sender}@s.whatsapp.net"


def is_group_jid(chat_jid: str) -> bool:
    return (chat_jid or "").endswith("@g.us")


def is_dm_jid(chat_jid: str) -> bool:
    return (chat_jid or "").endswith("@s.whatsapp.net") or (chat_jid or "").endswith("@lid")


# ---------------------------------------------------------------- filtering

def group_allowed(group_name: str | None) -> bool:
    lowered = (group_name or "").lower()
    if any(n in lowered for n in GROUP_DENY_NEEDLES):
        return False
    if GROUP_NAME_NEEDLES:
        return any(n in lowered for n in GROUP_NAME_NEEDLES)
    return True


def own_message_allowed(text: str) -> bool:
    if FORWARD_OWN == "all":
        return True
    if FORWARD_OWN == "deals_only" and OWN_RE is not None:
        return bool(OWN_RE.search(text or ""))
    return False


def classify(payload: dict) -> tuple[str, dict | None]:
    """Return (decision, accepted_message_or_None). Decision is a short reason."""
    from_me = payload.get("isFromMe") is True or payload.get("is_from_me") is True
    if from_me:
        own_text = payload.get("content") or payload.get("text") or ""
        if not isinstance(own_text, str) or not own_message_allowed(own_text):
            return "from_me", None

    chat_jid = (payload.get("chatJID") or payload.get("chat_jid") or "").strip()
    if not chat_jid:
        return "no_chat_jid", None
    if chat_jid.endswith("@broadcast") or chat_jid.endswith("@newsletter"):
        return "broadcast", None
    group = is_group_jid(chat_jid)
    if not group and not is_dm_jid(chat_jid):
        return "unknown_chat_type", None
    if not group and not ACCEPT_DMS:
        return "dm_disabled", None

    chat_name = (
        payload.get("group_name")
        or payload.get("groupName")
        or payload.get("chatName")
        or lookup_group_name(chat_jid)
    )
    if group and not group_allowed(chat_name):
        return f"group_filtered group={chat_name or '-'}", None

    event_type = (payload.get("eventType") or payload.get("event_type") or "").strip().lower()
    media_type = (payload.get("mediaType") or payload.get("media_type") or "").strip()
    content = payload.get("content") or payload.get("text") or ""
    if not isinstance(content, str):
        content = str(content) if content is not None else ""
    content = content.strip()

    if event_type in SKIP_MEDIA_TYPES or media_type.lower() in SKIP_MEDIA_TYPES:
        return "reaction_or_protocol", None
    if not content and not media_type:
        return "empty", None

    message_id = (payload.get("messageId") or payload.get("message_id") or "").strip()
    ts = lookup_timestamp(message_id, chat_jid)
    now = local_now()
    if ts is not None:
        age = (now - ts).total_seconds()
        if age > MAX_AGE_SEC:
            return f"too_old age_sec={int(age)}", None
        ts_out = ts.isoformat()
    else:
        # Live webhooks carry no timestamp; history sync does not fire webhooks.
        ts_out = now.isoformat()

    sender = (payload.get("sender") or payload.get("sender_jid") or "").strip()
    accepted = {
        "sender_name": lookup_sender_name(sender),
        "sender_jid": sender_jid(sender),
        "timestamp": ts_out,
        "text": content,
        "media_type": media_type or "",
        "from_me": from_me,
        "_chat_jid": chat_jid,
        "_group_name": chat_name or "",
    }
    return "accept", accepted


# ---------------------------------------------------------------- forwarding

def post_routine(body: dict) -> tuple[int | None, str | None]:
    if not ROUTINE_URL or "REPLACE_WITH" in ROUTINE_URL:
        return None, "routine_url_not_set"
    key = get_routine_key()
    if not key:
        return None, "missing_key"
    req = urllib.request.Request(
        ROUTINE_URL,
        data=json.dumps(body).encode("utf-8"),
        method="POST",
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            _ = resp.read()
            return resp.status, None
    except urllib.error.HTTPError as e:
        _ = e.read()
        return e.code, f"http_{e.code}"
    except Exception as e:
        return None, type(e).__name__


class Debouncer:
    """Collect messages per chat for DEBOUNCE_SEC, then forward them as one event.

    At most one forward per chat per RATE_LIMIT_SEC; extra messages roll into
    the next allowed window.
    """

    def __init__(self) -> None:
        self._cv = threading.Condition(threading.Lock())
        self._buffers: dict[str, dict[str, Any]] = {}
        self._last_forward: dict[str, float] = {}
        self._stop = False
        self._thread = threading.Thread(target=self._run, name="debounce", daemon=True)
        self._thread.start()

    def add(self, chat_jid: str, chat_name: str, message: dict) -> str:
        now = time.time()
        clean = {k: v for k, v in message.items() if not k.startswith("_")}
        with self._cv:
            buf = self._buffers.get(chat_jid)
            if buf is None:
                buf = {"group_name": chat_name, "messages": [], "ready_at": now + DEBOUNCE_SEC}
                self._buffers[chat_jid] = buf
                decision = "queued_new_window"
            else:
                decision = "queued_existing_window"
            buf["group_name"] = chat_name or buf.get("group_name") or ""
            buf["messages"].append(clean)
            self._cv.notify()
        return decision

    def stop(self) -> None:
        with self._cv:
            self._stop = True
            self._cv.notify()

    def _next_wake(self) -> float | None:
        if not self._buffers:
            return None
        return min(buf["ready_at"] for buf in self._buffers.values())

    def _run(self) -> None:
        while True:
            with self._cv:
                if self._stop:
                    return
                wake = self._next_wake()
                if wake is None:
                    self._cv.wait()
                    continue
                delay = wake - time.time()
                if delay > 0:
                    self._cv.wait(timeout=delay)
                    continue
                due = [(j, b) for j, b in list(self._buffers.items()) if b["ready_at"] <= time.time()]
            for jid, buf in due:
                self._flush_one(jid, buf)

    def _flush_one(self, chat_jid: str, buf: dict[str, Any]) -> None:
        now = time.time()
        last = self._last_forward.get(chat_jid, 0.0)
        if last and now < last + RATE_LIMIT_SEC:
            with self._cv:
                current = self._buffers.get(chat_jid)
                if current is not None:
                    ready = last + RATE_LIMIT_SEC
                    current["ready_at"] = ready
                    log(
                        f"rate_limit_hold chat={chat_jid} n={len(current.get('messages') or [])} "
                        f"wait_sec={int(ready - now)}"
                    )
            return
        with self._cv:
            current = self._buffers.pop(chat_jid, None)
            if current is None:
                return
            messages = list(current.get("messages") or [])
            chat_name = current.get("group_name") or ""
        if not messages:
            return
        body = {
            "group_name": chat_name,
            "chat_jid": chat_jid,
            "is_group": is_group_jid(chat_jid),
            "quiet_hours": in_quiet_hours(),
            "time_zone": TIME_ZONE,
            "messages": messages,
        }
        status, err = post_routine(body)
        self._last_forward[chat_jid] = time.time()
        if err:
            log(f"forward_error chat={chat_jid} n={len(messages)} status={status} err={err}")
        else:
            log(f"forward_ok chat={chat_jid} n={len(messages)} status={status}")


DEBOUNCER: Debouncer | None = None


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        log(f"http {self.address_string()} {fmt % args}")

    def _send(self, code: int, body: dict) -> None:
        raw = json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if self.path.split("?", 1)[0] == HEALTH_PATH:
            self._send(200, {"ok": True})
            return
        self._send(404, {"ok": False, "error": "not_found"})

    def do_POST(self) -> None:
        if self.path.split("?", 1)[0] != WEBHOOK_PATH:
            self._send(404, {"ok": False, "error": "not_found"})
            return
        token = load_bridge_token()
        provided = (self.headers.get("X-Bridge-Token") or "").strip()
        if token and provided != token:
            log("drop reason=bad_bridge_token")
            self._send(401, {"ok": False, "error": "unauthorized"})
            return
        length = int(self.headers.get("Content-Length") or 0)
        if length > 15 * 1024 * 1024:
            log("drop reason=too_large")
            self._send(413, {"ok": False, "error": "too_large"})
            return
        raw = self.rfile.read(length) if length else b""
        try:
            payload = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            log("drop reason=bad_json")
            self._send(400, {"ok": False, "error": "bad_json"})
            return
        if not isinstance(payload, dict):
            log("drop reason=not_object")
            self._send(400, {"ok": False, "error": "bad_json"})
            return
        payload.pop("mediaBase64", None)
        payload.pop("media_base64", None)

        chat_jid = (payload.get("chatJID") or payload.get("chat_jid") or "").strip()
        decision, accepted = classify(payload)
        if accepted is None:
            log(f"drop chat={chat_jid or '-'} reason={decision}")
            # 200 so the bridge does not retry drops.
            self._send(200, {"ok": True, "forwarded": False, "reason": decision})
            return
        assert DEBOUNCER is not None
        qdec = DEBOUNCER.add(chat_jid, accepted["_group_name"], accepted)
        log(f"accept chat={chat_jid} debounce={qdec}")
        self._send(200, {"ok": True, "forwarded": "queued", "reason": "accept"})


def already_running() -> int | None:
    try:
        pid = int(PID_PATH.read_text().strip())
    except Exception:
        return None
    try:
        os.kill(pid, 0)
        return pid
    except OSError:
        return None


def main() -> int:
    global DEBOUNCER
    if len(sys.argv) > 1 and sys.argv[1] == "--check-config":
        print(
            f"config ok: listen={LISTEN_HOST}:{LISTEN_PORT}{WEBHOOK_PATH} tz={TIME_ZONE} "
            f"accept_dms={ACCEPT_DMS} allow={len(GROUP_NAME_NEEDLES)} deny={len(GROUP_DENY_NEEDLES)} "
            f"own={FORWARD_OWN} routine_url_set={bool(ROUTINE_URL) and 'REPLACE_WITH' not in ROUTINE_URL} "
            f"key_present={bool(get_routine_key())}"
        )
        return 0
    existing = already_running()
    if existing and existing != os.getpid():
        print(f"relay already running (pid {existing})", flush=True)
        return 0
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    PID_PATH.write_text(f"{os.getpid()}\n")
    DEBOUNCER = Debouncer()
    log(f"relay_start pid={os.getpid()} listen={LISTEN_HOST}:{LISTEN_PORT}{WEBHOOK_PATH}")
    server = ThreadingHTTPServer((LISTEN_HOST, LISTEN_PORT), Handler)
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        DEBOUNCER.stop()
        server.server_close()
        try:
            if PID_PATH.read_text().strip() == str(os.getpid()):
                PID_PATH.unlink()
        except Exception:
            pass
        log("relay_stop")
    return 0


if __name__ == "__main__":
    sys.exit(main())
