package main

import (
	"fmt"
	"os"
	"strings"
)

// pairCodeFilePath is where a freshly generated phone-pairing code is written
// so it can be read without scraping the bridge log. The file is mode 0600.
// Set WA_PAIR_CODE_FILE to choose the path; the default is relative to the
// bridge working directory.
var pairCodeFilePath = func() string {
	if p := strings.TrimSpace(os.Getenv("WA_PAIR_CODE_FILE")); p != "" {
		return p
	}
	return "pair-code.txt"
}()

// writePairCode logs a phone-pairing code clearly and writes it to
// pairCodeFilePath. It is called only after PairPhone succeeds, never at
// process start.
func writePairCode(code string) {
	code = strings.TrimSpace(code)
	banner := fmt.Sprintf(`
====================================================================
  WHATSAPP PHONE PAIRING CODE
====================================================================
  Code: %s

  On the phone: WhatsApp > Settings > Linked Devices > Link a Device
  > Link with phone number instead, then enter the code above.

  Also written to: %s
  This code expires in a few minutes.
====================================================================
`, code, pairCodeFilePath)
	fmt.Print(banner)

	if err := os.WriteFile(pairCodeFilePath, []byte(code+"\n"), 0o600); err != nil {
		fmt.Printf("Warning: failed to write pairing code to %s: %v\n", pairCodeFilePath, err)
	}
}
