#!/usr/bin/env python3
"""Tiny config reader for the sales bot kit shell scripts.

Usage:
  kitconf.py get <dotted.key> [default]   print one value (lists print one item per line)
  kitconf.py path                         print the config file in use

Config lookup order: $KIT_CONFIG, then config.json next to this file,
then config.example.json next to this file. "install_dir" has ~ expanded.
Never reads or prints the routine webhook key.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def config_path() -> Path:
    env = (os.environ.get("KIT_CONFIG") or "").strip()
    if env:
        return Path(env).expanduser()
    for name in ("config.json", "config.example.json"):
        p = HERE / name
        if p.exists():
            return p
    return HERE / "config.json"


def load() -> dict:
    with config_path().open(encoding="utf-8") as f:
        return json.load(f)


def get(cfg: dict, dotted: str):
    cur = cfg
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            raise KeyError(dotted)
        cur = cur[part]
    if dotted == "install_dir" and isinstance(cur, str):
        cur = os.path.expanduser(cur)
    return cur


def main(argv: list[str]) -> int:
    if len(argv) >= 2 and argv[1] == "path":
        print(config_path())
        return 0
    if len(argv) < 3 or argv[1] != "get":
        print(__doc__, file=sys.stderr)
        return 2
    try:
        val = get(load(), argv[2])
    except KeyError:
        if len(argv) >= 4:
            print(argv[3])
            return 0
        print(f"missing config key: {argv[2]}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"config error: {type(e).__name__}: {e}", file=sys.stderr)
        return 1
    if isinstance(val, list):
        for item in val:
            print(item)
    elif isinstance(val, bool):
        print("true" if val else "false")
    elif isinstance(val, (dict,)):
        print(json.dumps(val))
    else:
        print(val)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
