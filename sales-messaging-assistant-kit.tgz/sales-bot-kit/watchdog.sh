#!/usr/bin/env bash
# Health watchdog for the WhatsApp bridge and local relay.
#
#   watchdog.sh          one check (safe to run from cron)
#   watchdog.sh --loop   check every watchdog.interval_sec forever (used by boot.sh)
#
# Restarts when the bridge or relay pid is dead, when the bridge health API
# says it is not connected, or when the bridge log shows the hang signature
# (for example repeated "Keepalive timed out" with no recovery since).
# Never pairs: it refuses to start without a linked session, and stops the
# bridge at once if a pairing code shows up after a restart.
# Alerts go to the routine webhook at most once per alert_cooldown_sec.
# Never prints or logs WA_ROUTINE_WEBHOOK_KEY or the key file contents.
# The key comes from WA_ROUTINE_WEBHOOK_KEY, or ~/.config/sales-bot-kit/routine_key.
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/lib.sh"

LOG="$RUN_DIR/watchdog.log"
STATE="$RUN_DIR/watchdog-state.json"
LOCK="$RUN_DIR/watchdog.lock"
START="$KIT_DIR/start-bridge.sh"
STOP="$KIT_DIR/stop-bridge.sh"
INTERVAL="$(conf watchdog.interval_sec 120)"
COOLDOWN="$(conf watchdog.alert_cooldown_sec 21600)"
HANG_THRESHOLD="$(conf bridge.hang_threshold 3)"
MAX_LOG_BYTES=$((50 * 1024 * 1024))

ts() { date '+%Y-%m-%d %H:%M:%S %Z'; }
wlog() {
  echo "$(ts) $*" >> "$LOG"
  if [[ -t 1 ]]; then echo "$(ts) $*"; fi
}

# Exit 0 (and print a count) if the bridge log shows a hang since the last
# start or recovery line.
hang_detected() {
  [[ -f "$BRIDGE_LOG" ]] || return 1
  python3 - "$BRIDGE_LOG" "$HANG_THRESHOLD" \
    "$(conf bridge.hang_signatures | paste -sd '|' -)" \
    "$(conf bridge.recovered_signatures | paste -sd '|' -)" <<'PY'
import os, re, sys
path, threshold, hang, ok = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
if not hang:
    sys.exit(1)
hang_re = re.compile("|".join(re.escape(s) for s in hang.split("|") if s), re.I)
ok_parts = [re.escape(s) for s in ok.split("|") if s] + [re.escape("=== bridge start")]
ok_re = re.compile("|".join(ok_parts), re.I)
with open(path, "rb") as f:
    f.seek(0, os.SEEK_END)
    f.seek(max(0, f.tell() - 300_000))
    lines = f.read().decode("utf-8", "replace").splitlines()
count = 0
for line in reversed(lines):
    if ok_re.search(line):
        break
    if hang_re.search(line):
        count += 1
print(count)
sys.exit(0 if count >= threshold else 1)
PY
}

pairing_started_since() {
  # True if a pair-code file was written after the given epoch second.
  [[ -f "$PAIR_CODE_FILE" ]] || return 1
  local since="$1" mtime
  mtime="$(stat -c %Y "$PAIR_CODE_FILE" 2>/dev/null || echo 0)"
  [[ "$mtime" -ge "$since" ]]
}

maybe_alert() {
  local detail="$1"
  python3 - "$STATE" "$(conf routine_url "")" "$detail" "$COOLDOWN" <<'PY'
import json, os, sys, time, urllib.request, urllib.error, pathlib
state_path, url, detail, cooldown = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
now = time.time()
p = pathlib.Path(state_path)
try:
    state = json.loads(p.read_text())
except Exception:
    state = {}
last = float(state.get("last_alert_ts") or 0)
if last and now - last < cooldown:
    print("alert_suppressed"); sys.exit(0)
if not url or "REPLACE_WITH" in url:
    print("alert_skipped routine_url_not_set"); sys.exit(0)
key = (os.environ.get("WA_ROUTINE_WEBHOOK_KEY") or "").strip()
if not key:
    override = (os.environ.get("WA_ROUTINE_KEY_FILE") or "").strip()
    if override:
        path = override
    else:
        xdg = (os.environ.get("XDG_CONFIG_HOME") or "").strip()
        base = xdg if xdg else os.path.expanduser("~/.config")
        path = os.path.join(base, "sales-bot-kit", "routine_key")
    try:
        key = pathlib.Path(path).read_text(encoding="utf-8").strip()
    except Exception:
        key = ""
if not key:
    print("alert_failed missing_key"); sys.exit(0)
body = json.dumps({"alert": "whatsapp_bridge_down", "detail": detail}).encode()
req = urllib.request.Request(url, data=body, method="POST", headers={
    "Authorization": f"Bearer {key}", "Content-Type": "application/json"})
try:
    with urllib.request.urlopen(req, timeout=30) as r:
        r.read(); status, err = r.status, None
except urllib.error.HTTPError as e:
    status, err = e.code, "http"
except Exception as e:
    status, err = None, type(e).__name__
state.update(last_alert_ts=now, last_alert_detail=detail, last_alert_status=status)
p.write_text(json.dumps(state) + "\n")
print(f"alert_{'failed' if err else 'sent'} status={status}")
PY
}

restart_bridge() {
  local reason="$1" t0
  if ! has_session; then
    wlog "refuse_restart reason=no_session"
    return 1
  fi
  wlog "restart reason=$reason"
  "$STOP" --bridge-only >> "$LOG" 2>&1 || true
  t0="$(date +%s)"
  "$START" >> "$LOG" 2>&1 || return 1
  for _ in $(seq 1 30); do
    if pairing_started_since "$t0"; then
      wlog "pairing_code_after_restart; stopping bridge now"
      "$STOP" --bridge-only >> "$LOG" 2>&1 || true
      return 2
    fi
    if [[ "$(health_snapshot)" == connected\|1\|* ]]; then
      wlog "recovered"
      return 0
    fi
    sleep 1
  done
  return 1
}

check_once() {
  # Keep the bridge log from filling the disk (appends use O_APPEND, so this is safe).
  if [[ -f "$BRIDGE_LOG" ]] && [[ "$(stat -c %s "$BRIDGE_LOG")" -gt "$MAX_LOG_BYTES" ]]; then
    tail -c 5000000 "$BRIDGE_LOG" > "$BRIDGE_LOG.tmp" && cat "$BRIDGE_LOG.tmp" > "$BRIDGE_LOG" && rm -f "$BRIDGE_LOG.tmp"
    wlog "bridge_log_trimmed"
  fi

  if ! has_session; then
    wlog "no_session; nothing to do (link with link-whatsapp.sh)"
    return 0
  fi

  local bpid rpid snap state connected paired http rc n
  bpid="$(bridge_pid || true)"
  rpid="$(relay_pid || true)"
  if [[ -z "$bpid" || -z "$rpid" ]] || ! relay_ok; then
    wlog "down bridge=${bpid:-none} relay=${rpid:-none}; starting"
    "$START" >> "$LOG" 2>&1 || { maybe_alert "start-bridge.sh failed" >> "$LOG"; return 0; }
    sleep 5
  fi

  snap="$(health_snapshot)"
  # Give a reconnect in progress up to 20 seconds before judging it.
  for _ in 1 2 3 4; do
    [[ "$snap" == connecting\|* ]] || break
    sleep 5
    snap="$(health_snapshot)"
  done
  IFS='|' read -r state connected paired http <<<"$snap"

  if [[ "$state" == "logged_out" || "$state" == "pairing" || ( "$snap" != ERROR* && "$paired" == "0" ) ]]; then
    wlog "logged_out_or_unpaired $snap; stopping bridge, not re-pairing"
    "$STOP" --bridge-only >> "$LOG" 2>&1 || true
    maybe_alert "WhatsApp is logged out (state=$state). Re-link with link-whatsapp.sh --force-relink." >> "$LOG"
    return 0
  fi

  if n="$(hang_detected)"; then
    rc=0; restart_bridge "hang_signature count=$n" || rc=$?
  elif [[ "$snap" == ERROR* || "$connected" != "1" ]]; then
    rc=0; restart_bridge "health $snap" || rc=$?
  else
    wlog "ok"
    return 0
  fi
  if [[ "$rc" -eq 2 ]]; then
    maybe_alert "bridge asked for pairing after a restart; stopped it" >> "$LOG"
  elif [[ "$rc" -ne 0 ]]; then
    maybe_alert "bridge not connected after restart ($(health_snapshot))" >> "$LOG"
  fi
}

exec 9>"$LOCK"
if ! flock -n 9; then
  echo "$(ts) another watchdog is running; exiting"
  exit 0
fi

if [[ "${1:-}" == "--loop" ]]; then
  wlog "watchdog_loop_start interval=${INTERVAL}s"
  while true; do
    check_once || wlog "check_failed"
    sleep "$INTERVAL"
  done
else
  check_once
fi
