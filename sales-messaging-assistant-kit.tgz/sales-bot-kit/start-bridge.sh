#!/usr/bin/env bash
# Start the local webhook relay and the WhatsApp bridge. Idempotent.
#
# Never starts the bridge without an existing linked session, so it can never
# trigger pairing. Link once with link-whatsapp.sh first.
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/lib.sh"

# --- relay first, so the bridge has somewhere to post ---
if [[ ! -f "$RELAY_PY" ]]; then
  echo "error: relay not found: $RELAY_PY" >&2
  exit 1
fi
if pid="$(relay_pid)"; then
  echo "relay already running (pid $pid)"
else
  RELAY_CONFIG="$(python3 "$CONF" path)" nohup python3 "$RELAY_PY" >> "$RELAY_LOG" 2>&1 &
  echo $! > "$RELAY_PIDFILE"
  echo "started relay (pid $(cat "$RELAY_PIDFILE")), log: $RELAY_LOG"
fi

# --- bridge ---
if [[ ! -x "$BIN" ]]; then
  echo "error: bridge binary missing: $BIN (run install.sh)" >&2
  exit 1
fi
if ! has_session; then
  echo "error: no linked WhatsApp session in $STORE_DB; refusing to start (it would start pairing). Run link-whatsapp.sh once." >&2
  exit 1
fi
if pid="$(bridge_pid)"; then
  echo "bridge already running (pid $pid)"
  exit 0
fi

cd "$BRIDGE_DIR"
unset WA_PAIR_PHONE || true   # this path must only reuse the existing session
export WEBHOOK_ENABLED=true
export WEBHOOK_URL="http://${RELAY_HOST}:${RELAY_PORT}${RELAY_WEBHOOK_PATH}"
export WHATSAPP_DEVICE_NAME="$DEVICE_NAME"
export WHATSAPP_BRIDGE_PORT="$BRIDGE_API_PORT"
export WA_PAIR_CODE_FILE="$PAIR_CODE_FILE"

echo "=== bridge start $(date '+%Y-%m-%d %H:%M:%S %Z') ===" >> "$BRIDGE_LOG"
nohup "$BIN" >> "$BRIDGE_LOG" 2>&1 &
echo $! > "$BRIDGE_PIDFILE"
echo "started bridge (pid $(cat "$BRIDGE_PIDFILE")), log: $BRIDGE_LOG"
