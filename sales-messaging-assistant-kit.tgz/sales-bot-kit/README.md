# Sales bot kit (WhatsApp + Lark)

A generic, person-neutral kit that lets a Grok Bot read a salesperson's WhatsApp (through a local bridge on the bot's box) and Lark (through the Lark web messenger in the bot's browser), draft replies in their voice, and send only after an explicit "send".

Start with **SETUP-GUIDE.md** (plain English, for the salesperson). The bot follows **SKILL.md**.

## Files

| File | What it is |
|---|---|
| `README.md` | This file. |
| `SETUP-GUIDE.md` | Step-by-step setup for a non-technical salesperson: install, link WhatsApp (QR or pairing code), create the routine and secret, run set-routine-key.sh, log in to Lark, troubleshooting. |
| `SKILL.md` | Draft Grok Bot skill `sales-messaging-assistant`: first-run profile and voice steps, hard rules, WhatsApp read/send, Lark via browser, welcome SOP with placeholders, read-aloud-before-send. |
| `install.sh` | Idempotent installer. Installs gcc, git, curl, Go, uv only if missing; clones whatsapp-mcp (pinned ref); applies the pairing patch; builds the bridge; `uv sync`; copies the kit into `<install_dir>/kit`; creates `config.json` if missing; installs autostart (`~/.config/autostart` entry, plus `@reboot` cron if cron exists); starts the boot/watchdog loop. Never pairs. |
| `config.example.json` | All settings: install dir, upstream repo/ref, time zone, quiet hours, routine URL placeholder, relay host/port/paths, debounce and rate limit, DM and group filters (allow and deny needles), own-message forwarding mode and deal regex, bridge port, device name, hang signatures, watchdog interval and alert cooldown. No secrets. |
| `kitconf.py` | Small config reader used by the shell scripts. |
| `lib.sh` | Shared paths and helpers (pid lookup, session check, health checks) sourced by the scripts. |
| `relay/relay.py` | Local webhook relay. Receives bridge webhooks, filters (broadcasts, reactions, deny/allow groups, DMs, own messages), debounces per chat, rate limits, and forwards to the routine URL with the key from `WA_ROUTINE_WEBHOOK_KEY`, or if that is unset, from `~/.config/sales-bot-kit/routine_key`. Never logs message text or the key. `--check-config` validates settings. |
| `set-routine-key.sh` | Writes the routine webhook key from the `WA_ROUTINE_WEBHOOK_KEY` environment variable (the Grok Bot secret) to `~/.config/sales-bot-kit/routine_key` (directory mode 0700, file mode 0600). Never prints the key. Run this once after the secret is saved, so the relay still works after a restart. |
| `start-bridge.sh` | Starts relay then bridge. Idempotent. Refuses to start the bridge without a linked session. |
| `stop-bridge.sh` | Stops bridge and relay (`--bridge-only` leaves the relay up). Never touches the session. |
| `watchdog.sh` | One health check, or `--loop`. Flock lock. Restarts on dead pid, not-connected health, or the hang signature in the log. Stops at once if a restart would pair. Alerts the routine at most once per cooldown. Trims the bridge log past 50 MB. |
| `boot.sh` | Run by autostart/cron: start-bridge.sh, then the watchdog loop. |
| `link-whatsapp.sh` | The only script that pairs. QR (terminal art plus `run/link-qr.png` for the bot to show) or 8-character code with `WA_PAIR_PHONE`. Refuses if already linked unless `--force-relink` (moves the old session aside, does not delete it). |
| `patches/0001-phone-number-pairing.patch` | Small patch to the upstream bridge (`connection.go`, `main.go`) that adds pairing-code linking via `WA_PAIR_PHONE`. |
| `patches/pair_phone.go` | Companion file for the patch; writes the code to `WA_PAIR_CODE_FILE` (mode 0600). |

Installed layout: `<install_dir>` is the whatsapp-mcp clone; the kit lives in `<install_dir>/kit`; runtime files (logs, pids, pair code, watchdog state) go in `<install_dir>/kit/run`.

## Deliberately excluded

- Any webhook key, routine URL, bridge token (`store/.bridge-token`), or WhatsApp session (`store/whatsapp.db`). Each person creates their own.
- Message stores (`store/messages.db`), logs, pid files, pair codes, backups.
- Any person's phone number, WhatsApp IDs, contact names, emails, group names, or deny-list entries. The example deny list is placeholders.
- Any Lark tenant URL or browser session. Each person logs in to their own tenant.
- Any person's voice guide, memories, deal log, calendar, or customer and brand names. The skill builds these per person on first run.
- Company-specific Lark custom app credentials (the admin option is described, not configured).

## Notes for whoever reviews this

- `upstream_ref` pins the whatsapp-mcp commit the patch was tested against. Moving to a newer upstream may need the patch refreshed; `install.sh` warns and continues with QR-only linking if it does not apply.
- After a restart the relay may not have `WA_ROUTINE_WEBHOOK_KEY` in its environment. Run `set-routine-key.sh` once after saving the bot secret; it writes `~/.config/sales-bot-kit/routine_key` (mode 0600). The relay and watchdog read the environment variable first, then that file. They never read another process's environment, and they never log the key.
- Forwarded events use `from_me` (true when the user wrote the message) and include `quiet_hours` and `time_zone`, so the routine can hold pings.
