#!/usr/bin/env bash
# Shared settings for the sales bot kit scripts. Sourced, not run.
# Every value comes from config.json (see kitconf.py for the lookup order).
# Never reads, prints, or logs WA_ROUTINE_WEBHOOK_KEY.

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="$KIT_DIR/kitconf.py"

conf() { python3 "$CONF" get "$@"; }

INSTALL_DIR="$(conf install_dir "$HOME/whatsapp-mcp")"
BRIDGE_DIR="$INSTALL_DIR/whatsapp-bridge"
BIN="$BRIDGE_DIR/whatsapp-bridge"
STORE_DB="$BRIDGE_DIR/store/whatsapp.db"
TOKEN_FILE="$BRIDGE_DIR/store/.bridge-token"
RUN_DIR="$KIT_DIR/run"
BRIDGE_LOG="$RUN_DIR/bridge.log"
BRIDGE_PIDFILE="$RUN_DIR/bridge.pid"
RELAY_PY="$KIT_DIR/relay/relay.py"
RELAY_LOG="$RUN_DIR/relay.log"
RELAY_PIDFILE="$RUN_DIR/relay.pid"
PAIR_CODE_FILE="$RUN_DIR/pair-code.txt"

RELAY_HOST="$(conf relay.listen_host 127.0.0.1)"
RELAY_PORT="$(conf relay.listen_port 8769)"
RELAY_WEBHOOK_PATH="$(conf relay.webhook_path /whatsapp/webhook)"
RELAY_HEALTH_PATH="$(conf relay.health_path /health)"
BRIDGE_API_PORT="$(conf bridge.api_port 8080)"
DEVICE_NAME="$(conf bridge.device_name "Chrome (Linux)")"

mkdir -p "$RUN_DIR"

is_running() {
  local pid="${1:-}"
  [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null
}

# Print the pid from a pidfile if alive, else find by pattern. Returns 1 if none.
find_pid() {
  local pidfile="$1" pattern="$2" pid=""
  if [[ -f "$pidfile" ]]; then
    pid="$(cat "$pidfile" 2>/dev/null || true)"
    if is_running "$pid"; then
      echo "$pid"
      return 0
    fi
    rm -f "$pidfile"
  fi
  pid="$(pgrep -f "$pattern" | head -n1 || true)"
  if [[ -n "$pid" ]]; then
    echo "$pid" > "$pidfile"
    echo "$pid"
    return 0
  fi
  return 1
}

bridge_pid() { find_pid "$BRIDGE_PIDFILE" "^${BIN}( |$)"; }
relay_pid() { find_pid "$RELAY_PIDFILE" "python3 ${RELAY_PY}"; }

# True when a linked WhatsApp device exists in the session store.
has_session() {
  [[ -f "$STORE_DB" ]] || return 1
  python3 - "$STORE_DB" <<'PY'
import sqlite3, sys
try:
    con = sqlite3.connect(f"file:{sys.argv[1]}?mode=ro", uri=True, timeout=5)
    n = con.execute("SELECT count(*) FROM whatsmeow_device WHERE jid IS NOT NULL AND jid != ''").fetchone()[0]
    con.close()
except Exception:
    sys.exit(1)
sys.exit(0 if n else 1)
PY
}

relay_ok() {
  python3 - "http://${RELAY_HOST}:${RELAY_PORT}${RELAY_HEALTH_PATH}" <<'PY'
import sys, urllib.request
try:
    with urllib.request.urlopen(sys.argv[1], timeout=3) as r:
        sys.exit(0 if r.status == 200 else 1)
except Exception:
    sys.exit(1)
PY
}

# Prints "STATE|CONNECTED|PAIRED|HTTP" or "ERROR|reason". Never prints the token.
health_snapshot() {
  python3 - "http://127.0.0.1:${BRIDGE_API_PORT}/api/health" "$TOKEN_FILE" <<'PY'
import json, sys, urllib.request, urllib.error, pathlib
url, token_path = sys.argv[1], sys.argv[2]
try:
    token = pathlib.Path(token_path).read_text().strip()
except Exception:
    print("ERROR|no_bridge_token"); sys.exit(0)
req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}", "Accept": "application/json"})
try:
    with urllib.request.urlopen(req, timeout=8) as r:
        body, code = r.read().decode("utf-8", "replace"), r.status
except urllib.error.HTTPError as e:
    body, code = e.read().decode("utf-8", "replace"), e.code
except Exception as e:
    print(f"ERROR|{type(e).__name__}"); sys.exit(0)
state, connected, paired = "unknown", "0", "0"
try:
    d = json.loads(body)
    state = str(d.get("state") or d.get("status") or "unknown")
    connected = "1" if d.get("connected") else "0"
    paired = "1" if d.get("paired") else "0"
except Exception:
    state = "unparseable"
print(f"{state}|{connected}|{paired}|{code}")
PY
}
