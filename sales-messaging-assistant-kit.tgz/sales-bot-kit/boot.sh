#!/usr/bin/env bash
# Run at login/boot (autostart entry and/or @reboot cron). Starts the relay and
# bridge if a linked session exists, then keeps the watchdog loop running.
# Safe to run more than once: start-bridge.sh is idempotent and the watchdog
# holds a lock, so a second loop exits at once.
set -uo pipefail
KIT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$KIT/run"
{
  echo "=== boot $(date '+%Y-%m-%d %H:%M:%S %Z') ==="
  sleep "${BOOT_DELAY_SEC:-15}"   # give the network a moment after a reboot
  "$KIT/start-bridge.sh" || echo "start-bridge.sh did not start the bridge (no session yet is normal before linking)"
} >> "$KIT/run/boot.log" 2>&1
exec "$KIT/watchdog.sh" --loop >> "$KIT/run/boot.log" 2>&1
