#!/usr/bin/env bash
# One-time WhatsApp link for this bot.
#
#   link-whatsapp.sh                    show a QR code (terminal + PNG) to scan
#   WA_PAIR_PHONE=15551234567 link-whatsapp.sh
#                                       get an 8-character pairing code instead
#   link-whatsapp.sh --force-relink     replace an existing session (old one is
#                                       moved aside, not deleted)
#
# On the phone: WhatsApp > Settings > Linked devices > Link a device.
# For a pairing code, tap "Link with phone number instead" and type the code.
#
# This is the ONLY script that can pair. start-bridge.sh and watchdog.sh never
# pair, and this script never runs on its own.
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/lib.sh"

FORCE=0
TIMEOUT_SEC="${LINK_TIMEOUT_SEC:-300}"
for arg in "$@"; do
  case "$arg" in
    --force-relink) FORCE=1 ;;
    -h|--help) sed -n '2,16p' "$0"; exit 0 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

QR_PNG="$RUN_DIR/link-qr.png"
QR_TXT="$RUN_DIR/link-qr.txt"

if [[ ! -x "$BIN" ]]; then
  echo "error: bridge not built yet. Run install.sh first." >&2
  exit 1
fi

if has_session; then
  if [[ "$FORCE" -ne 1 ]]; then
    echo "WhatsApp is already linked on this bot. Nothing to do."
    echo "To replace the link on purpose, run: $0 --force-relink"
    exit 0
  fi
  echo "--force-relink: stopping the bridge and moving the old session aside."
  "$KIT_DIR/stop-bridge.sh" --bridge-only || true
  stamp="$(date +%Y%m%d-%H%M%S)"
  for f in whatsapp.db whatsapp.db-wal whatsapp.db-shm; do
    [[ -f "$BRIDGE_DIR/store/$f" ]] && mv "$BRIDGE_DIR/store/$f" "$BRIDGE_DIR/store/$f.replaced-$stamp"
  done
fi

if pid="$(bridge_pid)"; then
  echo "A bridge is already running (pid $pid) without a session. Stopping it first."
  "$KIT_DIR/stop-bridge.sh" --bridge-only || true
fi

# Start the relay so messages flow as soon as the link completes.
if ! relay_pid >/dev/null; then
  RELAY_CONFIG="$(python3 "$CONF" path)" nohup python3 "$RELAY_PY" >> "$RELAY_LOG" 2>&1 &
  echo $! > "$RELAY_PIDFILE"
fi

rm -f "$PAIR_CODE_FILE" "$QR_PNG" "$QR_TXT"
cd "$BRIDGE_DIR"
export WEBHOOK_ENABLED=true
export WEBHOOK_URL="http://${RELAY_HOST}:${RELAY_PORT}${RELAY_WEBHOOK_PATH}"
export WHATSAPP_DEVICE_NAME="$DEVICE_NAME"
export WHATSAPP_BRIDGE_PORT="$BRIDGE_API_PORT"
export WA_PAIR_CODE_FILE="$PAIR_CODE_FILE"
if [[ -n "${WA_PAIR_PHONE:-}" ]]; then
  export WA_PAIR_PHONE="${WA_PAIR_PHONE//[^0-9]/}"
  echo "Pairing-code mode for the number ending in ${WA_PAIR_PHONE: -4}."
else
  unset WA_PAIR_PHONE || true
  echo "QR mode."
fi
echo "=== bridge start (link) $(date '+%Y-%m-%d %H:%M:%S %Z') ===" >> "$BRIDGE_LOG"
nohup "$BIN" >> "$BRIDGE_LOG" 2>&1 &
echo $! > "$BRIDGE_PIDFILE"
LINK_PID="$(cat "$BRIDGE_PIDFILE")"

cleanup_on_fail() {
  echo "Linking did not finish. Stopping the bridge so nothing is left half-paired."
  "$KIT_DIR/stop-bridge.sh" --bridge-only || true
  rm -f "$PAIR_CODE_FILE" "$QR_PNG" "$QR_TXT"
}

# Poll /api/connection, render each new QR, or show the pairing code, until linked.
set +e
python3 - "http://127.0.0.1:${BRIDGE_API_PORT}/api/connection" "$TOKEN_FILE" \
  "$QR_PNG" "$QR_TXT" "$PAIR_CODE_FILE" "$TIMEOUT_SEC" "$LINK_PID" <<'PY'
import json, os, pathlib, shutil, subprocess, sys, time, urllib.request, urllib.error
url, token_path, png, txt, code_path, timeout, pid = sys.argv[1:8]
deadline = time.time() + int(timeout)
last_qr, shown_code = None, False

def alive():
    try:
        os.kill(int(pid), 0); return True
    except Exception:
        return False

def get_status():
    try:
        token = pathlib.Path(token_path).read_text().strip()
    except Exception:
        return None
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read())
        except Exception:
            return None
    except Exception:
        return None

def render(code):
    # PNG for the bot to show in chat, text art for a real terminal.
    uv = shutil.which("uv")
    prog = (
        "import qrcode,sys\n"
        "q=qrcode.QRCode(border=2);q.add_data(sys.argv[1]);q.make(fit=True)\n"
        "q.make_image().save(sys.argv[2])\n"
        "f=open(sys.argv[3],'w');q.print_ascii(out=f,invert=True);f.close()\n"
    )
    cmd = ([uv, "run", "--quiet", "--with", "qrcode[pil]", "python", "-c", prog] if uv
           else [sys.executable, "-c", prog]) + [code, png, txt]
    ok = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    if ok:
        if sys.stdout.isatty():
            print(open(txt).read())
        print(f"QR saved to {png} (refreshes about every 20 seconds). Scan it from WhatsApp > Settings > Linked devices > Link a device.", flush=True)
    else:
        print("Could not render the QR image. Install python qrcode, or use WA_PAIR_PHONE for a pairing code.", flush=True)

while time.time() < deadline:
    if not alive():
        print("The bridge exited during linking. Check run/bridge.log.", flush=True)
        sys.exit(1)
    st = get_status() or {}
    if st.get("paired") and st.get("connected"):
        print("Linked. WhatsApp is connected.", flush=True)
        sys.exit(0)
    if not shown_code and os.path.exists(code_path):
        code = pathlib.Path(code_path).read_text().strip()
        if code:
            shown_code = True
            print(f"PAIRING CODE: {code}\nOn the phone: WhatsApp > Settings > Linked devices > Link a device > Link with phone number instead, then type the code. It expires in a few minutes.", flush=True)
    qr = st.get("qrCode")
    if qr and qr != last_qr and not os.environ.get("WA_PAIR_PHONE"):
        last_qr = qr
        render(qr)
    if st.get("state") == "error" and (st.get("lastError") or {}).get("code") in ("qr_timeout", "qr_closed"):
        print("QR expired before it was scanned.", flush=True)
        sys.exit(1)
    time.sleep(2)
print("Timed out waiting for the phone to link.", flush=True)
sys.exit(1)
PY
rc=$?
set -e
rm -f "$QR_PNG" "$QR_TXT"
if [[ "$rc" -ne 0 ]]; then
  cleanup_on_fail
  exit 1
fi
rm -f "$PAIR_CODE_FILE"
echo "Bridge is running (pid $LINK_PID). The watchdog will keep it up from now on."
