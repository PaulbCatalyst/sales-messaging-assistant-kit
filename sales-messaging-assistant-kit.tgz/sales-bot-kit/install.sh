#!/usr/bin/env bash
# Sales bot kit installer. Idempotent: safe to run again at any time.
#
#   ./install.sh [--install-dir DIR] [--no-start]
#
# 1. Installs gcc, git, Go and uv only when missing.
# 2. Clones whatsapp-mcp (pinned ref from config) into DIR (default $HOME/whatsapp-mcp),
#    applies the phone-number pairing patch, builds the bridge, runs uv sync.
# 3. Copies the kit (relay, start/stop, watchdog, link, boot) into DIR/kit and
#    creates DIR/kit/config.json from config.example.json if it does not exist.
# 4. Installs autostart (~/.config/autostart entry, plus @reboot cron when cron
#    exists) that runs boot.sh: start the bridge, then the watchdog loop.
# 5. Starts the watchdog loop now unless --no-start.
#
# It NEVER pairs WhatsApp. Run link-whatsapp.sh once afterwards for that.
# It never prints WA_ROUTINE_WEBHOOK_KEY. If that secret is already set,
# it runs set-routine-key.sh to write ~/.config/sales-bot-kit/routine_key.
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="${INSTALL_DIR:-}"
NO_START=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --install-dir) INSTALL_DIR="$2"; shift 2 ;;
    --no-start) NO_START=1; shift ;;
    -h|--help) sed -n '2,17p' "$0"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

say() { echo "[install] $*"; }
have() { command -v "$1" >/dev/null 2>&1; }

# Read a key from the example config (the real config may not exist yet).
exconf() { KIT_CONFIG="$SRC/config.example.json" python3 "$SRC/kitconf.py" get "$@"; }

if [[ -z "$INSTALL_DIR" ]]; then
  if [[ -f "$HOME/whatsapp-mcp/kit/config.json" ]]; then
    INSTALL_DIR="$(KIT_CONFIG="$HOME/whatsapp-mcp/kit/config.json" python3 "$SRC/kitconf.py" get install_dir)"
  else
    INSTALL_DIR="$HOME/whatsapp-mcp"
  fi
fi
INSTALL_DIR="${INSTALL_DIR/#\~/$HOME}"
KIT="$INSTALL_DIR/kit"
REPO="$(exconf upstream_repo)"
REF="$(exconf upstream_ref "")"

have python3 || { echo "python3 is required" >&2; exit 1; }

# ---------------------------------------------------------------- packages
SUDO=""
if [[ "$(id -u)" -ne 0 ]] && have sudo; then SUDO="sudo"; fi
apt_install() {
  if have apt-get; then
    say "installing $* with apt"
    $SUDO apt-get update -qq && $SUDO apt-get install -y -qq "$@"
  else
    echo "please install: $* (no apt-get found)" >&2
    exit 1
  fi
}
have gcc  || apt_install gcc
have git  || apt_install git
have curl || apt_install curl
have flock || apt_install util-linux

GO_MIN="1.26.0"
go_ok() {
  have go || return 1
  local v; v="$(go env GOVERSION 2>/dev/null | sed 's/^go//')"
  [[ "$(printf '%s\n%s\n' "$GO_MIN" "$v" | sort -V | head -n1)" == "$GO_MIN" ]]
}
if ! go_ok && [[ -x "$HOME/.local/go/bin/go" ]]; then
  export PATH="$HOME/.local/go/bin:$PATH"
fi
if ! go_ok; then
  arch="$(uname -m)"; case "$arch" in x86_64) arch=amd64 ;; aarch64|arm64) arch=arm64 ;; esac
  ver="$(curl -fsSL 'https://go.dev/VERSION?m=text' | head -n1)"
  say "installing $ver to $HOME/.local/go"
  rm -rf "$HOME/.local/go" && mkdir -p "$HOME/.local"
  curl -fsSL "https://go.dev/dl/${ver}.linux-${arch}.tar.gz" | tar -C "$HOME/.local" -xz
  export PATH="$HOME/.local/go/bin:$PATH"
fi
say "go: $(go version)"

if ! have uv; then
  [[ -x "$HOME/.local/bin/uv" ]] || { say "installing uv"; curl -LsSf https://astral.sh/uv/install.sh | sh; }
  export PATH="$HOME/.local/bin:$PATH"
fi
say "uv: $(uv --version)"

# ---------------------------------------------------------------- clone + patch + build
if [[ ! -d "$INSTALL_DIR/.git" ]]; then
  say "cloning $REPO into $INSTALL_DIR"
  git clone -q "$REPO" "$INSTALL_DIR"
  if [[ -n "$REF" ]]; then git -C "$INSTALL_DIR" checkout -q "$REF"; fi
else
  say "repo already present at $INSTALL_DIR (left as is)"
fi

BRIDGE="$INSTALL_DIR/whatsapp-bridge"
if grep -q "pairPhoneNumber" "$BRIDGE/connection.go" 2>/dev/null; then
  say "pairing patch already applied"
elif git -C "$INSTALL_DIR" apply --check "$SRC/patches/0001-phone-number-pairing.patch" 2>/dev/null; then
  git -C "$INSTALL_DIR" apply "$SRC/patches/0001-phone-number-pairing.patch"
  say "applied pairing patch"
else
  say "WARNING: pairing patch does not apply to this checkout. QR linking still works; pairing-code linking (WA_PAIR_PHONE) will not."
fi
if grep -q "pairPhoneNumber" "$BRIDGE/connection.go" 2>/dev/null; then
  cp "$SRC/patches/pair_phone.go" "$BRIDGE/pair_phone.go"
fi

needs_build=1
if [[ -x "$BRIDGE/whatsapp-bridge" ]] && [[ -z "$(find "$BRIDGE" -maxdepth 1 -name '*.go' -newer "$BRIDGE/whatsapp-bridge" -print -quit)" ]]; then
  needs_build=0
fi
if [[ "$needs_build" -eq 1 ]]; then
  say "building bridge"
  ( cd "$BRIDGE" && CGO_ENABLED=1 go build -o whatsapp-bridge.new . && mv -f whatsapp-bridge.new whatsapp-bridge )
else
  say "bridge binary is up to date"
fi

say "uv sync (MCP server)"
( cd "$INSTALL_DIR/whatsapp-mcp-server" && uv sync -q )

# ---------------------------------------------------------------- kit files
mkdir -p "$KIT/relay" "$KIT/run"
for f in lib.sh kitconf.py start-bridge.sh stop-bridge.sh watchdog.sh link-whatsapp.sh boot.sh set-routine-key.sh config.example.json; do
  install -m 0755 "$SRC/$f" "$KIT/$f"
done
chmod 0644 "$KIT/config.example.json"
install -m 0755 "$SRC/relay/relay.py" "$KIT/relay/relay.py"
if [[ ! -f "$KIT/config.json" ]]; then
  python3 - "$SRC/config.example.json" "$KIT/config.json" "$INSTALL_DIR" <<'PY'
import json, sys
src, dst, install_dir = sys.argv[1:4]
cfg = json.load(open(src))
cfg["install_dir"] = install_dir
with open(dst, "w") as f:
    json.dump(cfg, f, indent=2)
    f.write("\n")
PY
  chmod 0600 "$KIT/config.json"
  say "created $KIT/config.json (edit routine_url, time_zone, quiet_hours, filters)"
else
  say "kept existing $KIT/config.json"
fi
python3 -m py_compile "$KIT/relay/relay.py"
RELAY_CONFIG="$KIT/config.json" python3 "$KIT/relay/relay.py" --check-config

if [[ -n "${WA_ROUTINE_WEBHOOK_KEY:-}" ]]; then
  "$KIT/set-routine-key.sh"
  say "wrote the routine key file from WA_ROUTINE_WEBHOOK_KEY"
else
  say "WA_ROUTINE_WEBHOOK_KEY is not set yet; run $KIT/set-routine-key.sh after you save the bot secret"
fi

# ---------------------------------------------------------------- autostart
mkdir -p "$HOME/.config/autostart"
cat > "$HOME/.config/autostart/whatsapp-bridge-kit.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=WhatsApp bridge (sales bot kit)
Exec=/bin/bash -c 'setsid nohup "$KIT/boot.sh" >/dev/null 2>&1 &'
X-GNOME-Autostart-enabled=true
NoDisplay=true
DESKTOP
say "autostart entry: $HOME/.config/autostart/whatsapp-bridge-kit.desktop"

if have crontab; then
  line="@reboot $KIT/boot.sh >/dev/null 2>&1"
  if ! crontab -l 2>/dev/null | grep -Fq "$KIT/boot.sh"; then
    ( crontab -l 2>/dev/null || true; echo "$line" ) | crontab -
    say "added @reboot cron entry"
  else
    say "@reboot cron entry already present"
  fi
else
  say "no crontab on this machine; relying on the autostart entry"
fi

# ---------------------------------------------------------------- start watchdog
if [[ "$NO_START" -eq 0 ]]; then
  if pgrep -f "$KIT/watchdog.sh --loop" >/dev/null; then
    say "watchdog loop already running"
  else
    BOOT_DELAY_SEC=0 setsid nohup "$KIT/boot.sh" >/dev/null 2>&1 &
    say "started boot.sh (bridge if linked, then watchdog loop)"
  fi
fi

cat <<NEXT

Done. Next steps:
  1. Edit $KIT/config.json: routine_url, time_zone, quiet_hours, filters.
  2. Save the routine webhook key as a bot secret named WA_ROUTINE_WEBHOOK_KEY,
     then run:  $KIT/set-routine-key.sh
     That writes ~/.config/sales-bot-kit/routine_key (mode 0600) so the relay
     still works after a restart. Never paste the key into chat.
  3. Link WhatsApp once:   $KIT/link-whatsapp.sh
     (or for a code:       WA_PAIR_PHONE=<country code + number> $KIT/link-whatsapp.sh)
NEXT
